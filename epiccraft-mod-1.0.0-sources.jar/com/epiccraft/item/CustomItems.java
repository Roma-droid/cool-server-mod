package com.epiccraft.item;

import com.epiccraft.EpicCraftMod;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class CustomItems {

    // Custom item identifiers
    public static final class_2960 LOBBY_SWORD_ID = class_2960.method_60655(EpicCraftMod.MOD_ID, "lobby_sword");
    public static final class_2960 COIN_ID = class_2960.method_60655(EpicCraftMod.MOD_ID, "coin");
    public static final class_2960 TELEPORTER_ID = class_2960.method_60655(EpicCraftMod.MOD_ID, "teleporter");

    public static class_1792 LOBBY_SWORD;
    public static class_1792 COIN;
    public static class_1792 TELEPORTER;

    public static void register() {
        LOBBY_SWORD = registerItem("lobby_sword",
            new class_1792(new class_1792.class_1793().method_7889(1)));

        COIN = registerItem("coin",
            new class_1792(new class_1792.class_1793().method_7889(64)));

        TELEPORTER = registerItem("teleporter",
            new class_1792(new class_1792.class_1793().method_7889(1)));

        EpicCraftMod.LOGGER.info("Custom items registered!");
    }

    private static class_1792 registerItem(String name, class_1792 item) {
        return class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(EpicCraftMod.MOD_ID, name), item);
    }

    // Helper methods to create named item stacks for gameplay
    public static class_1799 createNamedStack(net.minecraft.class_1792 item, String name, int count) {
        class_1799 stack = new class_1799(item, count);
        stack.method_57379(net.minecraft.class_9334.field_49631,
            class_2561.method_43470(name));
        return stack;
    }

    public static class_1799 createSkyWarsKey() {
        return createNamedStack(class_1802.field_8366,
            "\u00a7b\u00a7lSkyWars Key \u00a77(Opens special chests)", 1);
    }

    public static class_1799 createBedWarsUpgradeToken() {
        return createNamedStack(class_1802.field_8137,
            "\u00a7c\u00a7lUpgrade Token \u00a77(Use at upgrade shop)", 1);
    }

    public static class_1799 createKitPvPBooster() {
        return createNamedStack(class_1802.field_8183,
            "\u00a7e\u00a7l2x Coins Booster \u00a77(5 minutes)", 1);
    }

    public static class_1799 createLobbyNavigator() {
        return createNamedStack(class_1802.field_8251,
            "\u00a7b\u00a7lGame Selector \u00a77(Right Click)", 1);
    }
}
