package com.epiccraft;

import com.epiccraft.command.CommandRegistrar;
import com.epiccraft.economy.EconomyManager;
import com.epiccraft.game.GameManager;
import com.epiccraft.item.CustomItems;
import com.epiccraft.lobby.LobbyManager;
import com.epiccraft.scoreboard.ScoreboardManager;
import com.epiccraft.stats.StatsManager;
import net.fabricmc.api.DedicatedServerModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.server.MinecraftServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EpicCraftMod implements DedicatedServerModInitializer {
    public static final String MOD_ID = "epiccraft";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static MinecraftServer server;
    private static EpicCraftMod instance;

    private GameManager gameManager;
    private LobbyManager lobbyManager;
    private EconomyManager economyManager;
    private StatsManager statsManager;
    private ScoreboardManager scoreboardManager;

    @Override
    public void onInitializeServer() {
        instance = this;
        LOGGER.info("========================================");
        LOGGER.info("  EpicCraft Server Mod v1.0.0");
        LOGGER.info("  Fabric 1.21.1 | Mini-Games Server");
        LOGGER.info("========================================");

        CustomItems.register();

        economyManager = new EconomyManager();
        statsManager = new StatsManager();
        gameManager = new GameManager();
        lobbyManager = new LobbyManager();
        scoreboardManager = new ScoreboardManager();

        registerEvents();
        CommandRegistrar.registerAll();

        LOGGER.info("EpicCraft initialized successfully!");
    }

    private void registerEvents() {
        ServerLifecycleEvents.SERVER_STARTED.register(s -> {
            server = s;
            lobbyManager.onServerStart(s);
            gameManager.onServerStart(s);
            LOGGER.info("EpicCraft server started!");
        });

        ServerLifecycleEvents.SERVER_STOPPING.register(s -> {
            gameManager.onServerStop();
            economyManager.saveAll();
            statsManager.saveAll();
            LOGGER.info("EpicCraft server stopping, data saved.");
        });

        ServerTickEvents.END_SERVER_TICK.register(s -> {
            gameManager.tick(s);
            scoreboardManager.tick(s);
        });

        ServerPlayConnectionEvents.JOIN.register((handler, sender, s) -> {
            var player = handler.method_32311();
            economyManager.loadPlayer(player);
            statsManager.loadPlayer(player);
            lobbyManager.sendToLobby(player);
            scoreboardManager.addPlayer(player);
            LOGGER.info("Player {} joined EpicCraft", player.method_5477().getString());
        });

        ServerPlayConnectionEvents.DISCONNECT.register((handler, s) -> {
            var player = handler.method_32311();
            gameManager.handlePlayerLeave(player);
            economyManager.savePlayer(player);
            statsManager.savePlayer(player);
            scoreboardManager.removePlayer(player);
        });
    }

    public static EpicCraftMod getInstance() {
        return instance;
    }

    public static MinecraftServer getServer() {
        return server;
    }

    public GameManager getGameManager() {
        return gameManager;
    }

    public LobbyManager getLobbyManager() {
        return lobbyManager;
    }

    public EconomyManager getEconomyManager() {
        return economyManager;
    }

    public StatsManager getStatsManager() {
        return statsManager;
    }

    public ScoreboardManager getScoreboardManager() {
        return scoreboardManager;
    }
}
