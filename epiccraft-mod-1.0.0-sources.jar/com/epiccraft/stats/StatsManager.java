package com.epiccraft.stats;

import com.epiccraft.EpicCraftMod;
import com.epiccraft.game.GameType;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_3222;

public class StatsManager {
    private static final Path DATA_FILE = Path.of("config/epiccraft/stats.json");
    private final Map<UUID, PlayerStats> playerStats = new ConcurrentHashMap<>();
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    public StatsManager() {
        loadAll();
    }

    public void loadPlayer(class_3222 player) {
        playerStats.putIfAbsent(player.method_5667(), new PlayerStats());
    }

    public void savePlayer(class_3222 player) {
        saveAll();
    }

    public void addKill(class_3222 player, GameType game) {
        getStats(player).addKill(game);
    }

    public void addDeath(class_3222 player, GameType game) {
        getStats(player).addDeath(game);
    }

    public void addWin(class_3222 player, GameType game) {
        getStats(player).addWin(game);
    }

    public void addGame(class_3222 player, GameType game) {
        getStats(player).addGame(game);
    }

    public int getKills(class_3222 player, GameType game) {
        return getStats(player).getKills(game);
    }

    public int getDeaths(class_3222 player, GameType game) {
        return getStats(player).getDeaths(game);
    }

    public int getWins(class_3222 player, GameType game) {
        return getStats(player).getWins(game);
    }

    public int getGamesPlayed(class_3222 player, GameType game) {
        return getStats(player).getGamesPlayed(game);
    }

    public int getTotalKills(class_3222 player) {
        int total = 0;
        for (GameType type : GameType.values()) {
            total += getKills(player, type);
        }
        return total;
    }

    public int getTotalWins(class_3222 player) {
        int total = 0;
        for (GameType type : GameType.values()) {
            total += getWins(player, type);
        }
        return total;
    }

    private PlayerStats getStats(class_3222 player) {
        return playerStats.computeIfAbsent(player.method_5667(), k -> new PlayerStats());
    }

    public void loadAll() {
        try {
            if (Files.exists(DATA_FILE)) {
                String json = Files.readString(DATA_FILE);
                Type type = new TypeToken<Map<String, PlayerStats>>() {}.getType();
                Map<String, PlayerStats> data = gson.fromJson(json, type);
                if (data != null) {
                    data.forEach((k, v) -> playerStats.put(UUID.fromString(k), v));
                }
                EpicCraftMod.LOGGER.info("Loaded {} player stats", playerStats.size());
            }
        } catch (Exception e) {
            EpicCraftMod.LOGGER.error("Failed to load stats data", e);
        }
    }

    public void saveAll() {
        try {
            Files.createDirectories(DATA_FILE.getParent());
            Map<String, PlayerStats> data = new HashMap<>();
            playerStats.forEach((k, v) -> data.put(k.toString(), v));
            Files.writeString(DATA_FILE, gson.toJson(data));
        } catch (Exception e) {
            EpicCraftMod.LOGGER.error("Failed to save stats data", e);
        }
    }

    public static class PlayerStats {
        private final Map<String, Integer> kills = new HashMap<>();
        private final Map<String, Integer> deaths = new HashMap<>();
        private final Map<String, Integer> wins = new HashMap<>();
        private final Map<String, Integer> gamesPlayed = new HashMap<>();

        public void addKill(GameType game) {
            kills.merge(game.getId(), 1, Integer::sum);
        }

        public void addDeath(GameType game) {
            deaths.merge(game.getId(), 1, Integer::sum);
        }

        public void addWin(GameType game) {
            wins.merge(game.getId(), 1, Integer::sum);
        }

        public void addGame(GameType game) {
            gamesPlayed.merge(game.getId(), 1, Integer::sum);
        }

        public int getKills(GameType game) {
            return kills.getOrDefault(game.getId(), 0);
        }

        public int getDeaths(GameType game) {
            return deaths.getOrDefault(game.getId(), 0);
        }

        public int getWins(GameType game) {
            return wins.getOrDefault(game.getId(), 0);
        }

        public int getGamesPlayed(GameType game) {
            return gamesPlayed.getOrDefault(game.getId(), 0);
        }
    }
}
