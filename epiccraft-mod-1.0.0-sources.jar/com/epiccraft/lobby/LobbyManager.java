package com.epiccraft.lobby;

import com.epiccraft.EpicCraftMod;
import com.epiccraft.game.GameType;
import com.epiccraft.util.LocationUtil;
import com.epiccraft.util.TextUtil;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.class_124;
import net.minecraft.class_1269;
import net.minecraft.class_1299;
import net.minecraft.class_1531;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1934;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public class LobbyManager {
    private static final class_2338 LOBBY_SPAWN = new class_2338(0, 100, 0);
    private static final int LOBBY_PLATFORM_RADIUS = 25;

    // NPC positions for game selection
    private static final class_2338 NPC_SKYWARS = new class_2338(10, 101, 0);
    private static final class_2338 NPC_BEDWARS = new class_2338(0, 101, 10);
    private static final class_2338 NPC_KITPVP = new class_2338(-10, 101, 0);

    private final Set<UUID> playersInLobby = new HashSet<>();
    private final Map<class_2338, GameType> npcPositions = new HashMap<>();

    public LobbyManager() {
        npcPositions.put(NPC_SKYWARS, GameType.SKYWARS);
        npcPositions.put(NPC_BEDWARS, GameType.BEDWARS);
        npcPositions.put(NPC_KITPVP, GameType.KITPVP);

        registerInteractions();
    }

    public void onServerStart(MinecraftServer server) {
        class_3218 world = server.method_30002();
        buildLobbyPlatform(world);
        spawnNPCs(world);
        EpicCraftMod.LOGGER.info("Lobby built at {} {} {}", LOBBY_SPAWN.method_10263(), LOBBY_SPAWN.method_10264(), LOBBY_SPAWN.method_10260());
    }

    public void sendToLobby(class_3222 player) {
        class_3218 world = player.method_5682().method_30002();
        LocationUtil.teleport(player, world,
            LOBBY_SPAWN.method_10263() + 0.5, LOBBY_SPAWN.method_10264() + 1, LOBBY_SPAWN.method_10260() + 0.5,
            0, 0);

        player.method_7336(class_1934.field_9216);
        player.method_31548().method_5448();
        player.method_6033(player.method_6063());
        player.method_7344().method_7580(20);

        giveLobbyItems(player);
        playersInLobby.add(player.method_5667());

        TextUtil.sendTitle(player, "\u00a7b\u00a7lEpicCraft", "\u00a77Welcome to the server!");
    }

    private void giveLobbyItems(class_3222 player) {
        // Game selector compass
        class_1799 compass = new class_1799(class_1802.field_8251);
        compass.method_57379(net.minecraft.class_9334.field_49631,
            class_2561.method_43470("\u00a7b\u00a7lGame Selector \u00a77(Right Click)").method_27692(class_124.field_1075));
        player.method_31548().method_5447(0, compass);

        // Profile book
        class_1799 book = new class_1799(class_1802.field_8529);
        book.method_57379(net.minecraft.class_9334.field_49631,
            class_2561.method_43470("\u00a7e\u00a7lProfile \u00a77(Right Click)").method_27692(class_124.field_1054));
        player.method_31548().method_5447(4, book);

        // Shop emerald
        class_1799 emerald = new class_1799(class_1802.field_8687);
        emerald.method_57379(net.minecraft.class_9334.field_49631,
            class_2561.method_43470("\u00a7a\u00a7lShop \u00a77(Right Click)").method_27692(class_124.field_1060));
        player.method_31548().method_5447(8, emerald);
    }

    private void registerInteractions() {
        // Handle right-click with compass (game selector)
        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            if (world.field_9236 || !(player instanceof class_3222 serverPlayer)) {
                return class_1269.field_5811;
            }
            if (!playersInLobby.contains(player.method_5667())) {
                return class_1269.field_5811;
            }

            class_1799 held = player.method_5998(hand);
            if (held.method_31574(class_1802.field_8251)) {
                openGameSelector(serverPlayer);
                return class_1269.field_5812;
            }
            if (held.method_31574(class_1802.field_8529)) {
                showProfile(serverPlayer);
                return class_1269.field_5812;
            }
            if (held.method_31574(class_1802.field_8687)) {
                showShop(serverPlayer);
                return class_1269.field_5812;
            }

            return class_1269.field_5811;
        });

        // Handle clicking on NPC armor stands
        UseEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (world.field_9236 || !(player instanceof class_3222 serverPlayer)) {
                return class_1269.field_5811;
            }
            if (!playersInLobby.contains(player.method_5667())) {
                return class_1269.field_5811;
            }

            if (entity instanceof class_1531) {
                class_2338 entityPos = entity.method_24515();
                for (Map.Entry<class_2338, GameType> entry : npcPositions.entrySet()) {
                    if (entry.getKey().method_19771(entityPos, 2)) {
                        joinGame(serverPlayer, entry.getValue());
                        return class_1269.field_5812;
                    }
                }
            }
            return class_1269.field_5811;
        });
    }

    private void openGameSelector(class_3222 player) {
        TextUtil.sendMessage(player, "\u00a76\u00a7l=== Game Selector ===");
        TextUtil.sendMessage(player, "");

        for (GameType type : GameType.values()) {
            var games = EpicCraftMod.getInstance().getGameManager().getGames(type);
            int totalPlayers = games.stream().mapToInt(g -> g.getPlayerCount()).sum();
            TextUtil.sendMessage(player, type.getColoredName() + " \u00a78| \u00a77" + totalPlayers + " playing \u00a78| \u00a7a/join " + type.getId());
        }

        TextUtil.sendMessage(player, "");
        TextUtil.sendMessage(player, "\u00a77Use \u00a7e/join <game> \u00a77to play!");
    }

    private void showProfile(class_3222 player) {
        var stats = EpicCraftMod.getInstance().getStatsManager();
        var economy = EpicCraftMod.getInstance().getEconomyManager();

        TextUtil.sendMessage(player, "\u00a76\u00a7l=== Your Profile ===");
        TextUtil.sendMessage(player, "\u00a7eCoins: \u00a76" + economy.getCoins(player));
        TextUtil.sendMessage(player, "");

        for (GameType type : GameType.values()) {
            int wins = stats.getWins(player, type);
            int totalGames = stats.getGamesPlayed(player, type);
            int kills = stats.getKills(player, type);
            TextUtil.sendMessage(player, type.getColoredName() + " \u00a78| \u00a7aW:" + wins + " \u00a78| \u00a7eG:" + totalGames + " \u00a78| \u00a7cK:" + kills);
        }
    }

    private void showShop(class_3222 player) {
        var economy = EpicCraftMod.getInstance().getEconomyManager();
        TextUtil.sendMessage(player, "\u00a76\u00a7l=== Shop ===");
        TextUtil.sendMessage(player, "\u00a7eYour coins: \u00a76" + economy.getCoins(player));
        TextUtil.sendMessage(player, "");
        TextUtil.sendMessage(player, "\u00a77Coming soon! Cosmetics and kits.");
    }

    private void joinGame(class_3222 player, GameType type) {
        playersInLobby.remove(player.method_5667());
        EpicCraftMod.getInstance().getGameManager().joinGame(player, type);
    }

    public boolean isInLobby(class_3222 player) {
        return playersInLobby.contains(player.method_5667());
    }

    public void removeFromLobby(class_3222 player) {
        playersInLobby.remove(player.method_5667());
    }

    private void buildLobbyPlatform(class_3218 world) {
        int y = LOBBY_SPAWN.method_10264();
        int cx = LOBBY_SPAWN.method_10263();
        int cz = LOBBY_SPAWN.method_10260();

        // Build circular platform
        for (int x = -LOBBY_PLATFORM_RADIUS; x <= LOBBY_PLATFORM_RADIUS; x++) {
            for (int z = -LOBBY_PLATFORM_RADIUS; z <= LOBBY_PLATFORM_RADIUS; z++) {
                double dist = Math.sqrt(x * x + z * z);
                if (dist <= LOBBY_PLATFORM_RADIUS) {
                    class_2338 pos = new class_2338(cx + x, y, cz + z);
                    if (dist > LOBBY_PLATFORM_RADIUS - 2) {
                        world.method_8501(pos, class_2246.field_10205.method_9564());
                    } else if ((x + z) % 2 == 0) {
                        world.method_8501(pos, class_2246.field_10153.method_9564());
                    } else {
                        world.method_8501(pos, class_2246.field_9978.method_9564());
                    }

                    // Clear space above
                    for (int dy = 1; dy <= 5; dy++) {
                        world.method_8501(pos.method_10086(dy), class_2246.field_10124.method_9564());
                    }
                }
            }
        }

        // Build game area indicators
        buildGamePedestal(world, NPC_SKYWARS, class_2246.field_10201.method_9564());
        buildGamePedestal(world, NPC_BEDWARS, class_2246.field_10002.method_9564());
        buildGamePedestal(world, NPC_KITPVP, class_2246.field_10205.method_9564());
    }

    private void buildGamePedestal(class_3218 world, class_2338 center, net.minecraft.class_2680 block) {
        int y = center.method_10264() - 1;
        for (int x = -1; x <= 1; x++) {
            for (int z = -1; z <= 1; z++) {
                world.method_8501(new class_2338(center.method_10263() + x, y, center.method_10260() + z), block);
            }
        }
    }

    private void spawnNPCs(class_3218 world) {
        spawnNPC(world, NPC_SKYWARS, "\u00a7b\u00a7lSkyWars", "\u00a77Click to play!");
        spawnNPC(world, NPC_BEDWARS, "\u00a7c\u00a7lBedWars", "\u00a77Click to play!");
        spawnNPC(world, NPC_KITPVP, "\u00a7e\u00a7lKitPvP", "\u00a77Click to play!");
    }

    private void spawnNPC(class_3218 world, class_2338 pos, String name, String subtitle) {
        // Main NPC armor stand
        class_1531 npc = new class_1531(class_1299.field_6131, world);
        npc.method_5814(pos.method_10263() + 0.5, pos.method_10264(), pos.method_10260() + 0.5);
        npc.method_5665(class_2561.method_43470(name));
        npc.method_5880(true);
        npc.method_5684(true);
        npc.method_5875(true);
        npc.method_6913(true);

        // Equip the NPC
        npc.method_5673(net.minecraft.class_1304.field_6169, new class_1799(class_1802.field_8805));
        npc.method_5673(net.minecraft.class_1304.field_6174, new class_1799(class_1802.field_8058));
        npc.method_5673(net.minecraft.class_1304.field_6172, new class_1799(class_1802.field_8348));
        npc.method_5673(net.minecraft.class_1304.field_6166, new class_1799(class_1802.field_8285));

        world.method_8649(npc);

        // Subtitle hologram
        class_1531 hologram = new class_1531(class_1299.field_6131, world);
        hologram.method_5814(pos.method_10263() + 0.5, pos.method_10264() - 0.3, pos.method_10260() + 0.5);
        hologram.method_5665(class_2561.method_43470(subtitle));
        hologram.method_5880(true);
        hologram.method_5648(true);
        hologram.method_5684(true);
        hologram.method_5875(true);
        world.method_8649(hologram);
    }
}
