package com.epiccraft.util;

import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public class LocationUtil {

    public static void teleport(class_3222 player, class_3218 world, double x, double y, double z) {
        teleport(player, world, x, y, z, player.method_36454(), player.method_36455());
    }

    public static void teleport(class_3222 player, class_3218 world, double x, double y, double z, float yaw, float pitch) {
        player.method_14251(world, x, y, z, yaw, pitch);
    }

    public static void teleport(class_3222 player, class_3218 world, class_2338 pos) {
        teleport(player, world, pos.method_10263() + 0.5, pos.method_10264(), pos.method_10260() + 0.5);
    }

    public static double distance(class_243 a, class_243 b) {
        return a.method_1022(b);
    }

    public static class_2338 toBlockPos(double x, double y, double z) {
        return new class_2338((int) x, (int) y, (int) z);
    }
}
