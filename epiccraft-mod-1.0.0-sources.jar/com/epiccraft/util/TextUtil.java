package com.epiccraft.util;

import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class TextUtil {
    public static final String PREFIX = "\u00a7b\u00a7lEpicCraft \u00a7f\u00a7l| \u00a77";

    public static void sendMessage(class_3222 player, String message) {
        player.method_7353(class_2561.method_43470(PREFIX + message), false);
    }

    public static void sendActionBar(class_3222 player, String message) {
        player.method_7353(class_2561.method_43470(message), true);
    }

    public static void sendTitle(class_3222 player, String title, String subtitle) {
        // Title and subtitle via commands for simplicity
        var server = player.method_5682();
        if (server != null) {
            server.method_3734().method_44252(
                server.method_3739().method_9217(),
                "title " + player.method_5477().getString() + " title " + formatJson(title)
            );
            if (subtitle != null) {
                server.method_3734().method_44252(
                    server.method_3739().method_9217(),
                    "title " + player.method_5477().getString() + " subtitle " + formatJson(subtitle)
                );
            }
        }
    }

    public static class_2561 colored(String text, class_124 color) {
        return class_2561.method_43470(text).method_27692(color);
    }

    public static class_2561 coloredBold(String text, class_124 color) {
        return class_2561.method_43470(text).method_27695(color, class_124.field_1067);
    }

    private static String formatJson(String text) {
        return "{\"text\":\"" + text.replace("\"", "\\\"") + "\"}";
    }

    public static String formatTime(int seconds) {
        int min = seconds / 60;
        int sec = seconds % 60;
        return String.format("%d:%02d", min, sec);
    }

    public static void broadcastToPlayers(Iterable<class_3222> players, String message) {
        for (class_3222 player : players) {
            sendMessage(player, message);
        }
    }
}
