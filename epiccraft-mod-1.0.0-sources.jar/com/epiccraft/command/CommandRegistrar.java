package com.epiccraft.command;

import com.epiccraft.EpicCraftMod;
import com.epiccraft.game.GameInstance;
import com.epiccraft.game.GameType;
import com.epiccraft.game.impl.KitPvPGame;
import com.epiccraft.util.TextUtil;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class CommandRegistrar {

    public static void registerAll() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {

            // /join <game>
            dispatcher.register(class_2170.method_9247("join")
                .then(class_2170.method_9244("game", StringArgumentType.word())
                    .suggests((context, builder) -> {
                        for (GameType type : GameType.values()) {
                            builder.suggest(type.getId());
                        }
                        return builder.buildFuture();
                    })
                    .executes(CommandRegistrar::executeJoin)));

            // /leave
            dispatcher.register(class_2170.method_9247("leave")
                .executes(context -> {
                    class_3222 player = context.getSource().method_9207();
                    EpicCraftMod.getInstance().getGameManager().handlePlayerLeave(player);
                    EpicCraftMod.getInstance().getLobbyManager().sendToLobby(player);
                    TextUtil.sendMessage(player, "\u00a7eYou left the game.");
                    return 1;
                }));

            // /lobby
            dispatcher.register(class_2170.method_9247("lobby")
                .executes(context -> {
                    class_3222 player = context.getSource().method_9207();
                    EpicCraftMod.getInstance().getGameManager().handlePlayerLeave(player);
                    EpicCraftMod.getInstance().getLobbyManager().sendToLobby(player);
                    return 1;
                }));

            // /hub (alias)
            dispatcher.register(class_2170.method_9247("hub")
                .executes(context -> {
                    class_3222 player = context.getSource().method_9207();
                    EpicCraftMod.getInstance().getGameManager().handlePlayerLeave(player);
                    EpicCraftMod.getInstance().getLobbyManager().sendToLobby(player);
                    return 1;
                }));

            // /stats [player]
            dispatcher.register(class_2170.method_9247("stats")
                .executes(context -> {
                    class_3222 player = context.getSource().method_9207();
                    showStats(player, player);
                    return 1;
                })
                .then(class_2170.method_9244("player", StringArgumentType.word())
                    .executes(context -> {
                        class_3222 source = context.getSource().method_9207();
                        String targetName = StringArgumentType.getString(context, "player");
                        class_3222 target = context.getSource().method_9211()
                            .method_3760().method_14566(targetName);
                        if (target == null) {
                            TextUtil.sendMessage(source, "\u00a7cPlayer not found!");
                            return 0;
                        }
                        showStats(source, target);
                        return 1;
                    })));

            // /coins
            dispatcher.register(class_2170.method_9247("coins")
                .executes(context -> {
                    class_3222 player = context.getSource().method_9207();
                    int coins = EpicCraftMod.getInstance().getEconomyManager().getCoins(player);
                    TextUtil.sendMessage(player, "\u00a7eYour coins: \u00a76" + coins);
                    return 1;
                }));

            // /kit <kit>
            dispatcher.register(class_2170.method_9247("kit")
                .then(class_2170.method_9244("kit", StringArgumentType.word())
                    .suggests((context, builder) -> {
                        for (KitPvPGame.Kit kit : KitPvPGame.Kit.values()) {
                            builder.suggest(kit.name().toLowerCase());
                        }
                        return builder.buildFuture();
                    })
                    .executes(context -> {
                        class_3222 player = context.getSource().method_9207();
                        String kitName = StringArgumentType.getString(context, "kit").toUpperCase();

                        GameInstance game = EpicCraftMod.getInstance().getGameManager().getPlayerGame(player);
                        if (!(game instanceof KitPvPGame kitPvP)) {
                            TextUtil.sendMessage(player, "\u00a7cYou must be in KitPvP to use this!");
                            return 0;
                        }

                        try {
                            KitPvPGame.Kit kit = KitPvPGame.Kit.valueOf(kitName);
                            kitPvP.selectKit(player, kit);
                        } catch (IllegalArgumentException e) {
                            TextUtil.sendMessage(player, "\u00a7cInvalid kit! Available: warrior, archer, tank, assassin");
                        }
                        return 1;
                    }))
                .executes(context -> {
                    class_3222 player = context.getSource().method_9207();
                    TextUtil.sendMessage(player, "\u00a76\u00a7l=== Kits ===");
                    for (KitPvPGame.Kit kit : KitPvPGame.Kit.values()) {
                        TextUtil.sendMessage(player, kit.color + "\u00a7l" + kit.name +
                            " \u00a78| \u00a77/kit " + kit.name().toLowerCase());
                    }
                    return 1;
                }));

            // /games - list all games
            dispatcher.register(class_2170.method_9247("games")
                .executes(context -> {
                    class_3222 player = context.getSource().method_9207();
                    TextUtil.sendMessage(player, "\u00a76\u00a7l=== Available Games ===");
                    TextUtil.sendMessage(player, "");

                    for (GameType type : GameType.values()) {
                        var games = EpicCraftMod.getInstance().getGameManager().getGames(type);
                        TextUtil.sendMessage(player, type.getColoredName() + "\u00a78:");
                        for (GameInstance game : games) {
                            String stateColor = switch (game.getState()) {
                                case WAITING -> "\u00a7a";
                                case STARTING -> "\u00a7e";
                                case IN_GAME -> "\u00a7c";
                                case ENDING -> "\u00a78";
                            };
                            TextUtil.sendMessage(player, "  \u00a78- \u00a7f" + game.getId() +
                                " " + stateColor + game.getState() +
                                " \u00a78[\u00a77" + game.getPlayerCount() + "/" + type.getMaxPlayers() + "\u00a78]");
                        }
                    }
                    return 1;
                }));

            // /pay <player> <amount>
            dispatcher.register(class_2170.method_9247("pay")
                .then(class_2170.method_9244("player", StringArgumentType.word())
                    .then(class_2170.method_9244("amount", StringArgumentType.word())
                        .executes(context -> {
                            class_3222 source = context.getSource().method_9207();
                            String targetName = StringArgumentType.getString(context, "player");
                            int amount;
                            try {
                                amount = Integer.parseInt(StringArgumentType.getString(context, "amount"));
                            } catch (NumberFormatException e) {
                                TextUtil.sendMessage(source, "\u00a7cInvalid amount!");
                                return 0;
                            }

                            if (amount <= 0) {
                                TextUtil.sendMessage(source, "\u00a7cAmount must be positive!");
                                return 0;
                            }

                            class_3222 target = context.getSource().method_9211()
                                .method_3760().method_14566(targetName);
                            if (target == null) {
                                TextUtil.sendMessage(source, "\u00a7cPlayer not found!");
                                return 0;
                            }

                            var economy = EpicCraftMod.getInstance().getEconomyManager();
                            if (!economy.removeCoins(source, amount)) {
                                TextUtil.sendMessage(source, "\u00a7cNot enough coins!");
                                return 0;
                            }

                            economy.addCoins(target, amount);
                            TextUtil.sendMessage(source, "\u00a7aSent \u00a76" + amount + " coins \u00a7ato " + target.method_5477().getString());
                            TextUtil.sendMessage(target, "\u00a7aReceived \u00a76" + amount + " coins \u00a7afrom " + source.method_5477().getString());
                            return 1;
                        }))));

        });

        EpicCraftMod.LOGGER.info("Commands registered!");
    }

    private static int executeJoin(CommandContext<class_2168> context) {
        try {
            class_3222 player = context.getSource().method_9207();
            String gameName = StringArgumentType.getString(context, "game").toLowerCase();

            GameType type = null;
            for (GameType gt : GameType.values()) {
                if (gt.getId().equals(gameName)) {
                    type = gt;
                    break;
                }
            }

            if (type == null) {
                TextUtil.sendMessage(player, "\u00a7cUnknown game! Available: skywars, bedwars, kitpvp");
                return 0;
            }

            EpicCraftMod.getInstance().getLobbyManager().removeFromLobby(player);
            EpicCraftMod.getInstance().getGameManager().joinGame(player, type);
            return 1;
        } catch (Exception e) {
            context.getSource().method_9213(class_2561.method_43470("Error: " + e.getMessage()));
            return 0;
        }
    }

    private static void showStats(class_3222 viewer, class_3222 target) {
        var stats = EpicCraftMod.getInstance().getStatsManager();
        var economy = EpicCraftMod.getInstance().getEconomyManager();

        TextUtil.sendMessage(viewer, "\u00a76\u00a7l=== Stats: " + target.method_5477().getString() + " ===");
        TextUtil.sendMessage(viewer, "\u00a7eCoins: \u00a76" + economy.getCoins(target));
        TextUtil.sendMessage(viewer, "");

        for (GameType type : GameType.values()) {
            int wins = stats.getWins(target, type);
            int games = stats.getGamesPlayed(target, type);
            int kills = stats.getKills(target, type);
            int deaths = stats.getDeaths(target, type);
            double kdr = deaths > 0 ? (double) kills / deaths : kills;

            TextUtil.sendMessage(viewer, type.getColoredName());
            TextUtil.sendMessage(viewer, "  \u00a7aWins: " + wins + " \u00a78| \u00a7eGames: " + games +
                " \u00a78| \u00a7cKills: " + kills + " \u00a78| \u00a77K/D: " + String.format("%.2f", kdr));
        }
    }
}
