package com.epiccraft.scoreboard;

import com.epiccraft.EpicCraftMod;
import com.epiccraft.game.GameInstance;
import com.epiccraft.game.GameState;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_269;
import net.minecraft.class_274;
import net.minecraft.class_3222;
import net.minecraft.class_8646;
import net.minecraft.class_9014;
import net.minecraft.class_9015;
import net.minecraft.scoreboard.*;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public class ScoreboardManager {
    private final Set<UUID> activePlayers = new HashSet<>();
    private int tickCounter = 0;

    public void addPlayer(class_3222 player) {
        activePlayers.add(player.method_5667());
    }

    public void removePlayer(class_3222 player) {
        activePlayers.remove(player.method_5667());
        clearScoreboard(player);
    }

    public void tick(MinecraftServer server) {
        tickCounter++;
        if (tickCounter % 20 != 0) return; // Update every second

        for (UUID playerId : activePlayers) {
            class_3222 player = server.method_3760().method_14602(playerId);
            if (player != null) {
                updateScoreboard(player);
            }
        }
    }

    private void updateScoreboard(class_3222 player) {
        var server = player.method_5682();
        if (server == null) return;

        class_269 scoreboard = server.method_3845();

        // Remove old objective if exists
        class_266 oldObj = scoreboard.method_1170("epiccraft_sb");
        if (oldObj != null) {
            scoreboard.method_1194(oldObj);
        }

        // Create new objective
        class_266 objective = scoreboard.method_1168(
            "epiccraft_sb",
            class_274.field_1468,
            class_2561.method_43470("\u00a7b\u00a7lEpicCraft").method_27695(class_124.field_1075, class_124.field_1067),
            class_274.class_275.field_1472,
            true,
            null
        );
        scoreboard.method_1158(class_8646.field_45157, objective);

        var economy = EpicCraftMod.getInstance().getEconomyManager();
        var stats = EpicCraftMod.getInstance().getStatsManager();
        var gameManager = EpicCraftMod.getInstance().getGameManager();
        GameInstance currentGame = gameManager.getPlayerGame(player);

        int line = 15;

        setScore(scoreboard, objective, "\u00a77\u00a7m        \u00a7r\u00a7b\u00a7l EpicCraft \u00a77\u00a7m        ", line--);
        setScore(scoreboard, objective, " ", line--);

        if (currentGame != null) {
            setScore(scoreboard, objective, "\u00a7fGame: " + currentGame.getType().getColoredName(), line--);
            setScore(scoreboard, objective, "\u00a7fStatus: " + getStateDisplay(currentGame.getState()), line--);
            setScore(scoreboard, objective, "\u00a7fPlayers: \u00a7a" + currentGame.getPlayerCount() + "/" + currentGame.getType().getMaxPlayers(), line--);
            setScore(scoreboard, objective, "  ", line--);
        }

        setScore(scoreboard, objective, "\u00a7eCoins: \u00a76" + economy.getCoins(player), line--);
        setScore(scoreboard, objective, "\u00a7aWins: \u00a7f" + stats.getTotalWins(player), line--);
        setScore(scoreboard, objective, "\u00a7cKills: \u00a7f" + stats.getTotalKills(player), line--);
        setScore(scoreboard, objective, "   ", line--);
        setScore(scoreboard, objective, "\u00a7ePlayers: \u00a7f" + server.method_3760().method_14571().size(), line--);
        setScore(scoreboard, objective, "    ", line--);
        setScore(scoreboard, objective, "\u00a7bplay.epiccraft.net", line);
    }

    private void setScore(class_269 scoreboard, class_266 objective, String text, int score) {
        // Use the text as the player name for the score entry
        class_9015 holder = class_9015.method_55422(text);
        class_9014 access = scoreboard.method_1180(holder, objective);
        access.method_55410(score);
    }

    private String getStateDisplay(GameState state) {
        return switch (state) {
            case WAITING -> "\u00a7eWaiting";
            case STARTING -> "\u00a76Starting";
            case IN_GAME -> "\u00a7aIn Game";
            case ENDING -> "\u00a7cEnding";
        };
    }

    private void clearScoreboard(class_3222 player) {
        var server = player.method_5682();
        if (server == null) return;
        class_269 scoreboard = server.method_3845();
        class_266 obj = scoreboard.method_1170("epiccraft_sb");
        if (obj != null) {
            scoreboard.method_1194(obj);
        }
    }
}
