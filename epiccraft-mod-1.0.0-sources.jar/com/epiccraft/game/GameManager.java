package com.epiccraft.game;

import com.epiccraft.EpicCraftMod;
import com.epiccraft.game.impl.BedWarsGame;
import com.epiccraft.game.impl.KitPvPGame;
import com.epiccraft.game.impl.SkyWarsGame;
import com.epiccraft.util.TextUtil;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public class GameManager {
    private final Map<String, GameInstance> games = new LinkedHashMap<>();
    private final Map<UUID, String> playerGameMap = new HashMap<>();
    private int gameIdCounter = 0;

    public void onServerStart(MinecraftServer server) {
        // Create default game instances
        createGame(GameType.SKYWARS);
        createGame(GameType.SKYWARS);
        createGame(GameType.BEDWARS);
        createGame(GameType.BEDWARS);
        createGame(GameType.KITPVP);

        // Register death event
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, damageSource) -> {
            if (entity instanceof class_3222 player) {
                GameInstance game = getPlayerGame(player);
                if (game != null && game.getState() == GameState.IN_GAME) {
                    game.eliminatePlayer(player);
                }
            }
        });

        EpicCraftMod.LOGGER.info("GameManager: Created {} default game instances", games.size());
    }

    public void onServerStop() {
        for (GameInstance game : games.values()) {
            if (game.getState() == GameState.IN_GAME || game.getState() == GameState.STARTING) {
                game.cleanup();
            }
        }
    }

    public GameInstance createGame(GameType type) {
        String id = type.getId() + "-" + (++gameIdCounter);
        GameInstance game = switch (type) {
            case SKYWARS -> new SkyWarsGame(id);
            case BEDWARS -> new BedWarsGame(id);
            case KITPVP -> new KitPvPGame(id);
        };
        games.put(id, game);
        return game;
    }

    public void joinGame(class_3222 player, GameType type) {
        // Leave current game if in one
        handlePlayerLeave(player);

        // Find available game
        GameInstance game = findAvailableGame(type);
        if (game == null) {
            game = createGame(type);
        }

        playerGameMap.put(player.method_5667(), game.getId());
        game.addPlayer(player);
    }

    public void joinSpecificGame(class_3222 player, String gameId) {
        GameInstance game = games.get(gameId);
        if (game == null) {
            TextUtil.sendMessage(player, "\u00a7cGame not found!");
            return;
        }

        handlePlayerLeave(player);
        playerGameMap.put(player.method_5667(), game.getId());
        game.addPlayer(player);
    }

    public void handlePlayerLeave(class_3222 player) {
        String gameId = playerGameMap.remove(player.method_5667());
        if (gameId != null) {
            GameInstance game = games.get(gameId);
            if (game != null) {
                game.removePlayer(player);
            }
        }
    }

    public GameInstance getPlayerGame(class_3222 player) {
        String gameId = playerGameMap.get(player.method_5667());
        return gameId != null ? games.get(gameId) : null;
    }

    public GameInstance findAvailableGame(GameType type) {
        for (GameInstance game : games.values()) {
            if (game.getType() == type
                && (game.getState() == GameState.WAITING || game.getState() == GameState.STARTING)
                && game.getPlayerCount() < type.getMaxPlayers()) {
                return game;
            }
        }
        return null;
    }

    public List<GameInstance> getGames(GameType type) {
        List<GameInstance> result = new ArrayList<>();
        for (GameInstance game : games.values()) {
            if (game.getType() == type) {
                result.add(game);
            }
        }
        return result;
    }

    public void tick(MinecraftServer server) {
        for (GameInstance game : games.values()) {
            if (game.getState() != GameState.WAITING || !game.getPlayers().isEmpty()) {
                game.tick(server);
            }
        }
    }

    public Collection<GameInstance> getAllGames() {
        return Collections.unmodifiableCollection(games.values());
    }
}
