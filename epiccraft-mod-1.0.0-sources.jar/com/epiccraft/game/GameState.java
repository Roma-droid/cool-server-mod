package com.epiccraft.game;

public enum GameState {
    WAITING,
    STARTING,
    IN_GAME,
    ENDING
}
