package com.epiccraft.game;

import com.epiccraft.EpicCraftMod;
import com.epiccraft.util.TextUtil;
import net.minecraft.class_1934;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public abstract class GameInstance {
    protected final String id;
    protected final GameType type;
    protected GameState state;
    protected final List<class_3222> players = new ArrayList<>();
    protected final List<class_3222> spectators = new ArrayList<>();
    protected final List<UUID> alivePlayers = new ArrayList<>();
    protected int countdown;
    protected int gameTimer;
    protected int tickCounter;

    private static final int COUNTDOWN_SECONDS = 15;

    public GameInstance(String id, GameType type) {
        this.id = id;
        this.type = type;
        this.state = GameState.WAITING;
        this.countdown = COUNTDOWN_SECONDS;
        this.gameTimer = type.getGameDurationSeconds() > 0 ? type.getGameDurationSeconds() * 20 : -1;
        this.tickCounter = 0;
    }

    public void addPlayer(class_3222 player) {
        if (state != GameState.WAITING && state != GameState.STARTING) {
            TextUtil.sendMessage(player, "\u00a7cThis game has already started!");
            return;
        }
        if (players.size() >= type.getMaxPlayers()) {
            TextUtil.sendMessage(player, "\u00a7cThis game is full!");
            return;
        }

        players.add(player);
        alivePlayers.add(player.method_5667());
        player.method_7336(class_1934.field_9216);
        player.method_31548().method_5448();

        broadcastMessage("\u00a7a" + player.method_5477().getString() + " \u00a77joined! \u00a78(" + players.size() + "/" + type.getMaxPlayers() + ")");

        teleportToWaitingArea(player);
        onPlayerJoin(player);

        if (players.size() >= type.getMinPlayers() && state == GameState.WAITING) {
            state = GameState.STARTING;
            countdown = COUNTDOWN_SECONDS;
            broadcastMessage("\u00a7eGame starting in \u00a7c" + COUNTDOWN_SECONDS + " \u00a7eseconds!");
        }
    }

    public void removePlayer(class_3222 player) {
        players.remove(player);
        alivePlayers.remove(player.method_5667());
        spectators.remove(player);

        broadcastMessage("\u00a7c" + player.method_5477().getString() + " \u00a77left! \u00a78(" + players.size() + "/" + type.getMaxPlayers() + ")");

        onPlayerLeave(player);

        if (state == GameState.IN_GAME) {
            checkWinCondition();
        }

        if (players.size() < type.getMinPlayers() && state == GameState.STARTING) {
            state = GameState.WAITING;
            broadcastMessage("\u00a7cNot enough players. Waiting for more...");
        }
    }

    public void eliminatePlayer(class_3222 player) {
        alivePlayers.remove(player.method_5667());
        spectators.add(player);
        player.method_7336(class_1934.field_9219);

        broadcastMessage("\u00a7c\u2620 \u00a77" + player.method_5477().getString() + " \u00a7cwas eliminated!");
        TextUtil.sendTitle(player, "\u00a7c\u00a7lELIMINATED", "\u00a77You are now spectating");

        onPlayerEliminated(player);
        checkWinCondition();
    }

    public void tick(MinecraftServer server) {
        tickCounter++;

        switch (state) {
            case STARTING -> {
                if (tickCounter % 20 == 0) {
                    countdown--;
                    if (countdown <= 0) {
                        startGame(server);
                    } else if (countdown <= 5 || countdown == 10) {
                        broadcastMessage("\u00a7eStarting in \u00a7c" + countdown + "\u00a7e...");
                        for (class_3222 p : players) {
                            TextUtil.sendActionBar(p, "\u00a7e\u00a7l" + countdown);
                        }
                    }
                }
            }
            case IN_GAME -> {
                onTick(server);
                if (gameTimer > 0) {
                    gameTimer--;
                    if (gameTimer <= 0) {
                        endGame(null);
                    } else if (tickCounter % 20 == 0) {
                        int seconds = gameTimer / 20;
                        for (class_3222 p : players) {
                            TextUtil.sendActionBar(p, "\u00a7e\u23F1 " + TextUtil.formatTime(seconds));
                        }
                    }
                }
            }
            case ENDING -> {
                if (tickCounter % 20 == 0) {
                    countdown--;
                    if (countdown <= 0) {
                        cleanup();
                    }
                }
            }
        }
    }

    protected void startGame(MinecraftServer server) {
        state = GameState.IN_GAME;
        tickCounter = 0;

        broadcastMessage(type.getColoredName() + " \u00a7ahas started!");

        for (class_3222 player : players) {
            player.method_7336(class_1934.field_9215);
            player.method_31548().method_5448();
            player.method_6033(player.method_6063());
            player.method_7344().method_7580(20);
            TextUtil.sendTitle(player, type.getColoredName(), "\u00a7aGood luck!");
        }

        onGameStart(server);
    }

    protected void endGame(class_3222 winner) {
        state = GameState.ENDING;
        countdown = 10;
        tickCounter = 0;

        if (winner != null) {
            broadcastMessage("\u00a76\u00a7l\u2B50 \u00a7e" + winner.method_5477().getString() + " \u00a76won the game!");
            TextUtil.sendTitle(winner, "\u00a76\u00a7lVICTORY!", "\u00a7eYou won the game!");

            var economy = EpicCraftMod.getInstance().getEconomyManager();
            economy.addCoins(winner, 50);
            TextUtil.sendMessage(winner, "\u00a7a+50 coins for winning!");

            var stats = EpicCraftMod.getInstance().getStatsManager();
            stats.addWin(winner, type);
        } else {
            broadcastMessage("\u00a7c\u00a7lGame Over! \u00a77No winner.");
        }

        for (class_3222 p : players) {
            var stats = EpicCraftMod.getInstance().getStatsManager();
            stats.addGame(p, type);
        }

        onGameEnd(winner);
    }

    protected void cleanup() {
        for (class_3222 player : new ArrayList<>(players)) {
            player.method_31548().method_5448();
            player.method_6033(player.method_6063());
            player.method_7344().method_7580(20);
            EpicCraftMod.getInstance().getLobbyManager().sendToLobby(player);
        }
        players.clear();
        spectators.clear();
        alivePlayers.clear();

        state = GameState.WAITING;
        countdown = COUNTDOWN_SECONDS;
        gameTimer = type.getGameDurationSeconds() > 0 ? type.getGameDurationSeconds() * 20 : -1;
        tickCounter = 0;

        onCleanup();
    }

    protected void checkWinCondition() {
        if (state != GameState.IN_GAME) return;
        List<class_3222> alive = getAlivePlayers();
        if (alive.size() <= 1) {
            endGame(alive.isEmpty() ? null : alive.get(0));
        }
    }

    protected List<class_3222> getAlivePlayers() {
        List<class_3222> alive = new ArrayList<>();
        for (class_3222 p : players) {
            if (alivePlayers.contains(p.method_5667())) {
                alive.add(p);
            }
        }
        return alive;
    }

    protected void broadcastMessage(String message) {
        TextUtil.broadcastToPlayers(players, message);
    }

    // Abstract methods for game implementations
    protected abstract void teleportToWaitingArea(class_3222 player);
    protected abstract void onPlayerJoin(class_3222 player);
    protected abstract void onPlayerLeave(class_3222 player);
    protected abstract void onPlayerEliminated(class_3222 player);
    protected abstract void onGameStart(MinecraftServer server);
    protected abstract void onGameEnd(class_3222 winner);
    protected abstract void onTick(MinecraftServer server);
    protected abstract void onCleanup();

    // Getters
    public String getId() { return id; }
    public GameType getType() { return type; }
    public GameState getState() { return state; }
    public List<class_3222> getPlayers() { return Collections.unmodifiableList(players); }
    public int getPlayerCount() { return players.size(); }
    public boolean hasPlayer(class_3222 player) { return players.contains(player); }
}
