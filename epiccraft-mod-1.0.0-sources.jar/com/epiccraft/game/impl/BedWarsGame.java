package com.epiccraft.game.impl;

import com.epiccraft.game.GameInstance;
import com.epiccraft.game.GameState;
import com.epiccraft.game.GameType;
import com.epiccraft.util.LocationUtil;
import com.epiccraft.util.TextUtil;
import net.minecraft.class_124;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2244;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2742;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public class BedWarsGame extends GameInstance {
    private static final int ISLAND_Y = 100;
    private static final int ISLAND_DISTANCE = 50;
    private static final int ISLAND_RADIUS = 8;

    private final List<TeamData> teams = new ArrayList<>();
    private final Map<UUID, TeamData> playerTeams = new HashMap<>();
    private int generatorTick = 0;

    // Team colors and data
    private static final class_124[] TEAM_COLORS = {
        class_124.field_1061, class_124.field_1078, class_124.field_1060, class_124.field_1054
    };
    private static final String[] TEAM_NAMES = {"Red", "Blue", "Green", "Yellow"};
    private static final class_1767[] BED_COLORS = {
        class_1767.field_7964, class_1767.field_7966, class_1767.field_7942, class_1767.field_7947
    };

    public BedWarsGame(String id) {
        super(id, GameType.BEDWARS);
        initTeams();
    }

    private void initTeams() {
        int numTeams = 4;
        class_2338 origin = new class_2338(1000, ISLAND_Y, 1000);

        for (int i = 0; i < numTeams; i++) {
            double angle = (2 * Math.PI * i) / numTeams;
            int x = origin.method_10263() + (int) (ISLAND_DISTANCE * Math.cos(angle));
            int z = origin.method_10260() + (int) (ISLAND_DISTANCE * Math.sin(angle));
            class_2338 spawn = new class_2338(x, ISLAND_Y + 1, z);
            class_2338 bedPos = new class_2338(x + 3, ISLAND_Y + 1, z);

            teams.add(new TeamData(TEAM_NAMES[i], TEAM_COLORS[i], BED_COLORS[i], spawn, bedPos));
        }
    }

    @Override
    protected void teleportToWaitingArea(class_3222 player) {
        // Assign to smallest team
        TeamData smallest = null;
        int minSize = Integer.MAX_VALUE;
        for (TeamData team : teams) {
            if (team.members.size() < minSize) {
                minSize = team.members.size();
                smallest = team;
            }
        }

        if (smallest != null) {
            smallest.members.add(player.method_5667());
            playerTeams.put(player.method_5667(), smallest);

            class_3218 world = player.method_5682().method_30002();
            LocationUtil.teleport(player, world,
                smallest.spawn.method_10263() + 0.5, smallest.spawn.method_10264() + 1, smallest.spawn.method_10260() + 0.5);

            TextUtil.sendMessage(player, "\u00a77You joined team " + smallest.color + "\u00a7l" + smallest.name + "\u00a77!");
        }
    }

    @Override
    protected void onPlayerJoin(class_3222 player) {
        // Give team info
    }

    @Override
    protected void onPlayerLeave(class_3222 player) {
        TeamData team = playerTeams.remove(player.method_5667());
        if (team != null) {
            team.members.remove(player.method_5667());
        }
    }

    @Override
    protected void onPlayerEliminated(class_3222 player) {
        TeamData team = playerTeams.get(player.method_5667());
        if (team != null && team.bedAlive) {
            // Bed is alive - respawn player
            alivePlayers.add(player.method_5667());
            spectators.remove(player);
            player.method_7336(net.minecraft.class_1934.field_9215);

            class_3218 world = player.method_5682().method_30002();
            LocationUtil.teleport(player, world,
                team.spawn.method_10263() + 0.5, team.spawn.method_10264() + 1, team.spawn.method_10260() + 0.5);

            player.method_6033(player.method_6063());
            giveRespawnKit(player);

            TextUtil.sendMessage(player, "\u00a7aYou respawned! Your bed is still intact.");
        }
    }

    @Override
    protected void onGameStart(MinecraftServer server) {
        class_3218 world = server.method_30002();

        // Build team islands
        for (TeamData team : teams) {
            buildTeamIsland(world, team);
        }

        // Build center island
        buildCenterIsland(world, new class_2338(1000, ISLAND_Y + 5, 1000));

        // Give starting kits
        for (class_3222 player : players) {
            giveStartingKit(player);
        }

        broadcastMessage("\u00a7c\u00a7lBedWars \u00a7a- Destroy enemy beds and be the last team standing!");
        broadcastMessage("\u00a77Iron and Gold spawn at your base. Diamonds spawn at center!");
    }

    @Override
    protected void onGameEnd(class_3222 winner) {
        // Nothing extra
    }

    @Override
    protected void onTick(MinecraftServer server) {
        generatorTick++;

        // Resource generators - every 2 seconds give iron
        if (generatorTick % 40 == 0) {
            for (TeamData team : teams) {
                for (UUID memberId : team.members) {
                    class_3222 player = server.method_3760().method_14602(memberId);
                    if (player != null && alivePlayers.contains(memberId)) {
                        player.method_31548().method_7394(new class_1799(class_1802.field_8620, 2));
                    }
                }
            }
        }

        // Every 10 seconds give gold
        if (generatorTick % 200 == 0) {
            for (TeamData team : teams) {
                for (UUID memberId : team.members) {
                    class_3222 player = server.method_3760().method_14602(memberId);
                    if (player != null && alivePlayers.contains(memberId)) {
                        player.method_31548().method_7394(new class_1799(class_1802.field_8695, 1));
                    }
                }
            }
        }

        // Check bed status
        if (generatorTick % 20 == 0) {
            class_3218 world = server.method_30002();
            for (TeamData team : teams) {
                if (team.bedAlive) {
                    class_2680 bedState = world.method_8320(team.bedPos);
                    if (!(bedState.method_26204() instanceof class_2244)) {
                        team.bedAlive = false;
                        broadcastMessage(team.color + "\u00a7l" + team.name + "'s \u00a7cbed was destroyed!");

                        // Notify team members
                        for (UUID memberId : team.members) {
                            class_3222 p = server.method_3760().method_14602(memberId);
                            if (p != null) {
                                TextUtil.sendTitle(p, "\u00a7c\u00a7lBED DESTROYED!", "\u00a77You can no longer respawn!");
                            }
                        }
                    }
                }
            }

            // Check team elimination
            checkTeamWinCondition(server);
        }

        // Void check
        for (class_3222 player : new ArrayList<>(getAlivePlayers())) {
            if (player.method_23318() < 50) {
                eliminatePlayer(player);
            }
        }
    }

    private void checkTeamWinCondition(MinecraftServer server) {
        List<TeamData> aliveTeams = new ArrayList<>();
        for (TeamData team : teams) {
            boolean hasAliveMember = false;
            for (UUID memberId : team.members) {
                if (alivePlayers.contains(memberId)) {
                    hasAliveMember = true;
                    break;
                }
            }
            if (hasAliveMember || team.bedAlive) {
                aliveTeams.add(team);
            }
        }

        if (aliveTeams.size() <= 1) {
            if (aliveTeams.isEmpty()) {
                endGame(null);
            } else {
                TeamData winningTeam = aliveTeams.get(0);
                broadcastMessage(winningTeam.color + "\u00a7lTeam " + winningTeam.name + " \u00a76wins!");

                // Find first alive player from winning team
                for (UUID memberId : winningTeam.members) {
                    class_3222 p = server.method_3760().method_14602(memberId);
                    if (p != null && alivePlayers.contains(memberId)) {
                        endGame(p);
                        return;
                    }
                }
                endGame(null);
            }
        }
    }

    @Override
    protected void checkWinCondition() {
        // Override - BedWars uses team-based win condition in onTick
    }

    @Override
    protected void onCleanup() {
        playerTeams.clear();
        generatorTick = 0;
        for (TeamData team : teams) {
            team.members.clear();
            team.bedAlive = true;
        }
    }

    private void buildTeamIsland(class_3218 world, TeamData team) {
        class_2338 center = team.spawn.method_10074();

        for (int x = -ISLAND_RADIUS; x <= ISLAND_RADIUS; x++) {
            for (int z = -ISLAND_RADIUS; z <= ISLAND_RADIUS; z++) {
                double dist = Math.sqrt(x * x + z * z);
                if (dist <= ISLAND_RADIUS) {
                    class_2338 pos = center.method_10069(x, 0, z);
                    world.method_8501(pos, class_2246.field_10446.method_9564());
                    world.method_8501(pos.method_10074(), class_2246.field_9979.method_9564());
                    for (int dy = 1; dy <= 10; dy++) {
                        world.method_8501(pos.method_10086(dy), class_2246.field_10124.method_9564());
                    }
                }
            }
        }

        // Place bed
        world.method_8501(team.bedPos, class_2246.field_10069.method_9564()
            .method_11657(class_2244.field_9967, class_2742.field_12557)
            .method_11657(class_2244.field_11177, class_2350.field_11043));
        world.method_8501(team.bedPos.method_10095(), class_2246.field_10069.method_9564()
            .method_11657(class_2244.field_9967, class_2742.field_12560)
            .method_11657(class_2244.field_11177, class_2350.field_11043));
    }

    private void buildCenterIsland(class_3218 world, class_2338 center) {
        int radius = 10;
        for (int x = -radius; x <= radius; x++) {
            for (int z = -radius; z <= radius; z++) {
                double dist = Math.sqrt(x * x + z * z);
                if (dist <= radius) {
                    class_2338 pos = center.method_10069(x, 0, z);
                    world.method_8501(pos, class_2246.field_10540.method_9564());
                    for (int dy = 1; dy <= 10; dy++) {
                        world.method_8501(pos.method_10086(dy), class_2246.field_10124.method_9564());
                    }
                }
            }
        }

        // Diamond generators
        world.method_8501(center.method_10084(), class_2246.field_10201.method_9564());
    }

    private void giveStartingKit(class_3222 player) {
        player.method_31548().method_5448();
        player.method_31548().method_5447(0, new class_1799(class_1802.field_8091));
        player.method_31548().method_5447(1, new class_1799(class_1802.field_8647));
        player.method_31548().method_5447(2, new class_1799(class_1802.field_8406));
        player.method_31548().method_5447(3, new class_1799(class_1802.field_8868));
    }

    private void giveRespawnKit(class_3222 player) {
        player.method_31548().method_5448();
        player.method_31548().method_5447(0, new class_1799(class_1802.field_8091));
        player.method_31548().method_5447(1, new class_1799(class_1802.field_8647));
    }

    static class TeamData {
        final String name;
        final class_124 color;
        final class_1767 dyeColor;
        final class_2338 spawn;
        final class_2338 bedPos;
        final List<UUID> members = new ArrayList<>();
        boolean bedAlive = true;

        TeamData(String name, class_124 color, class_1767 dyeColor, class_2338 spawn, class_2338 bedPos) {
            this.name = name;
            this.color = color;
            this.dyeColor = dyeColor;
            this.spawn = spawn;
            this.bedPos = bedPos;
        }
    }
}
