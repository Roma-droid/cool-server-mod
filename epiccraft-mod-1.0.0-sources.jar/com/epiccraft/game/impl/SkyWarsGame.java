package com.epiccraft.game.impl;

import com.epiccraft.game.GameInstance;
import com.epiccraft.game.GameType;
import com.epiccraft.util.LocationUtil;
import com.epiccraft.util.TextUtil;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public class SkyWarsGame extends GameInstance {
    private static final int ISLAND_RADIUS = 5;
    private static final int ISLAND_Y = 120;
    private static final int ISLAND_DISTANCE = 30;
    private static final int CENTER_Y = 125;

    private final List<class_2338> islandSpawns = new ArrayList<>();
    private final Map<UUID, Integer> playerIslands = new HashMap<>();
    private class_2338 arenaOrigin;
    private int chestRefillTimer;
    private boolean chestsRefilled;

    public SkyWarsGame(String id) {
        super(id, GameType.SKYWARS);
        calculateSpawns();
        chestRefillTimer = 0;
        chestsRefilled = false;
    }

    private void calculateSpawns() {
        // Generate island positions in a circle
        int numIslands = type.getMaxPlayers();
        arenaOrigin = new class_2338(500, ISLAND_Y, 500); // Offset from lobby

        for (int i = 0; i < numIslands; i++) {
            double angle = (2 * Math.PI * i) / numIslands;
            int x = arenaOrigin.method_10263() + (int) (ISLAND_DISTANCE * Math.cos(angle));
            int z = arenaOrigin.method_10260() + (int) (ISLAND_DISTANCE * Math.sin(angle));
            islandSpawns.add(new class_2338(x, ISLAND_Y + 1, z));
        }
    }

    @Override
    protected void teleportToWaitingArea(class_3222 player) {
        int index = players.indexOf(player);
        if (index >= 0 && index < islandSpawns.size()) {
            playerIslands.put(player.method_5667(), index);
            class_3218 world = player.method_5682().method_30002();
            class_2338 spawn = islandSpawns.get(index);
            LocationUtil.teleport(player, world, spawn.method_10263() + 0.5, spawn.method_10264() + 1, spawn.method_10260() + 0.5);
        }
    }

    @Override
    protected void onPlayerJoin(class_3222 player) {
        // Players wait on their islands
    }

    @Override
    protected void onPlayerLeave(class_3222 player) {
        playerIslands.remove(player.method_5667());
    }

    @Override
    protected void onPlayerEliminated(class_3222 player) {
        // Drop items at death location
    }

    @Override
    protected void onGameStart(MinecraftServer server) {
        class_3218 world = server.method_30002();

        // Build all islands
        for (class_2338 spawn : islandSpawns) {
            buildIsland(world, spawn.method_10074());
        }

        // Build center island
        buildCenterIsland(world, new class_2338(arenaOrigin.method_10263(), CENTER_Y, arenaOrigin.method_10260()));

        // Give starting kits
        for (class_3222 player : players) {
            giveStartingKit(player);
        }

        // Chest refill after 2 minutes
        chestRefillTimer = 2 * 60 * 20;
        chestsRefilled = false;

        broadcastMessage("\u00a7b\u00a7lSkyWars \u00a7a- Fight to be the last one standing!");
        broadcastMessage("\u00a77Chests will refill in \u00a7e2 minutes\u00a77!");
    }

    @Override
    protected void onGameEnd(class_3222 winner) {
        // Nothing extra
    }

    @Override
    protected void onTick(MinecraftServer server) {
        // Chest refill countdown
        if (!chestsRefilled && chestRefillTimer > 0) {
            chestRefillTimer--;
            if (chestRefillTimer <= 0) {
                chestsRefilled = true;
                broadcastMessage("\u00a7e\u00a7lChests have been refilled!");
                // Refill chest items for remaining players
                for (class_3222 player : getAlivePlayers()) {
                    giveRefillKit(player);
                }
            }
        }

        // Void check - eliminate players who fall
        for (class_3222 player : new ArrayList<>(getAlivePlayers())) {
            if (player.method_23318() < 50) {
                eliminatePlayer(player);
            }
        }
    }

    @Override
    protected void onCleanup() {
        playerIslands.clear();
        chestsRefilled = false;
        chestRefillTimer = 0;
    }

    private void buildIsland(class_3218 world, class_2338 center) {
        // Build a small floating island
        for (int x = -ISLAND_RADIUS; x <= ISLAND_RADIUS; x++) {
            for (int z = -ISLAND_RADIUS; z <= ISLAND_RADIUS; z++) {
                double dist = Math.sqrt(x * x + z * z);
                if (dist <= ISLAND_RADIUS) {
                    class_2338 pos = center.method_10069(x, 0, z);
                    world.method_8501(pos, class_2246.field_10219.method_9564());
                    world.method_8501(pos.method_10074(), class_2246.field_10566.method_9564());
                    world.method_8501(pos.method_10087(2), class_2246.field_10340.method_9564());

                    // Clear above
                    for (int dy = 1; dy <= 10; dy++) {
                        world.method_8501(pos.method_10086(dy), class_2246.field_10124.method_9564());
                    }
                }
            }
        }

        // Place a chest on each island
        world.method_8501(center.method_10084(), class_2246.field_10034.method_9564());

        // Small tree
        class_2338 treeBase = center.method_10069(2, 1, 2);
        for (int dy = 0; dy < 4; dy++) {
            world.method_8501(treeBase.method_10086(dy), class_2246.field_10431.method_9564());
        }
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                world.method_8501(treeBase.method_10069(dx, 4, dz), class_2246.field_10503.method_9564());
                world.method_8501(treeBase.method_10069(dx, 3, dz), class_2246.field_10503.method_9564());
            }
        }
    }

    private void buildCenterIsland(class_3218 world, class_2338 center) {
        int radius = 8;
        for (int x = -radius; x <= radius; x++) {
            for (int z = -radius; z <= radius; z++) {
                double dist = Math.sqrt(x * x + z * z);
                if (dist <= radius) {
                    class_2338 pos = center.method_10069(x, 0, z);
                    world.method_8501(pos, class_2246.field_10540.method_9564());
                    world.method_8501(pos.method_10074(), class_2246.field_10471.method_9564());
                    for (int dy = 1; dy <= 10; dy++) {
                        world.method_8501(pos.method_10086(dy), class_2246.field_10124.method_9564());
                    }
                }
            }
        }

        // Center beacon-like structure
        world.method_8501(center.method_10084(), class_2246.field_10485.method_9564());

        // Chests around center
        world.method_8501(center.method_10069(3, 1, 0), class_2246.field_10034.method_9564());
        world.method_8501(center.method_10069(-3, 1, 0), class_2246.field_10034.method_9564());
        world.method_8501(center.method_10069(0, 1, 3), class_2246.field_10034.method_9564());
        world.method_8501(center.method_10069(0, 1, -3), class_2246.field_10034.method_9564());
    }

    private void giveStartingKit(class_3222 player) {
        player.method_31548().method_5448();

        player.method_31548().method_5447(0, new class_1799(class_1802.field_8528));
        player.method_31548().method_5447(1, new class_1799(class_1802.field_8102));
        player.method_31548().method_5447(2, new class_1799(class_1802.field_8387));
        player.method_31548().method_5447(3, new class_1799(class_1802.field_8062));

        player.method_31548().method_5447(4, new class_1799(class_1802.field_8118, 64));
        player.method_31548().method_5447(5, new class_1799(class_1802.field_8463, 3));
        player.method_31548().method_5447(6, new class_1799(class_1802.field_8107, 16));

        // Leather armor
        player.method_31548().field_7548.set(0, new class_1799(class_1802.field_8370));
        player.method_31548().field_7548.set(1, new class_1799(class_1802.field_8570));
        player.method_31548().field_7548.set(2, new class_1799(class_1802.field_8577));
        player.method_31548().field_7548.set(3, new class_1799(class_1802.field_8267));
    }

    private void giveRefillKit(class_3222 player) {
        player.method_31548().method_7394(new class_1799(class_1802.field_8371));
        player.method_31548().method_7394(new class_1799(class_1802.field_8463, 2));
        player.method_31548().method_7394(new class_1799(class_1802.field_8107, 8));
        player.method_31548().method_7394(new class_1799(class_1802.field_8634, 2));
        player.method_31548().method_7394(new class_1799(class_1802.field_8523));
    }
}
