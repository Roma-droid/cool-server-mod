package com.epiccraft.game.impl;

import com.epiccraft.EpicCraftMod;
import com.epiccraft.game.GameInstance;
import com.epiccraft.game.GameState;
import com.epiccraft.game.GameType;
import com.epiccraft.util.LocationUtil;
import com.epiccraft.util.TextUtil;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1934;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public class KitPvPGame extends GameInstance {
    private static final class_2338 ARENA_CENTER = new class_2338(2000, 100, 2000);
    private static final int ARENA_RADIUS = 30;

    private final Map<UUID, Kit> playerKits = new HashMap<>();
    private final Map<UUID, Integer> killStreaks = new HashMap<>();
    private final Map<UUID, Integer> killCounts = new HashMap<>();
    private final Random random = new Random();

    public enum Kit {
        WARRIOR("Warrior", class_124.field_1061, class_1802.field_8371, class_1802.field_8523),
        ARCHER("Archer", class_124.field_1060, class_1802.field_8102, class_1802.field_8577),
        TANK("Tank", class_124.field_1078, class_1802.field_8528, class_1802.field_8058),
        ASSASSIN("Assassin", class_124.field_1064, class_1802.field_8802, class_1802.field_8873);

        public final String name;
        public final class_124 color;
        public final net.minecraft.class_1792 weapon;
        public final net.minecraft.class_1792 chest;

        Kit(String name, class_124 color, net.minecraft.class_1792 weapon, net.minecraft.class_1792 chest) {
            this.name = name;
            this.color = color;
            this.weapon = weapon;
            this.chest = chest;
        }
    }

    public KitPvPGame(String id) {
        super(id, GameType.KITPVP);
    }

    @Override
    protected void teleportToWaitingArea(class_3222 player) {
        class_3218 world = player.method_5682().method_30002();
        LocationUtil.teleport(player, world,
            ARENA_CENTER.method_10263() + 0.5, ARENA_CENTER.method_10264() + 1, ARENA_CENTER.method_10260() + 0.5);
    }

    @Override
    protected void onPlayerJoin(class_3222 player) {
        // Show kit selection
        showKitSelection(player);
    }

    @Override
    protected void onPlayerLeave(class_3222 player) {
        playerKits.remove(player.method_5667());
        killStreaks.remove(player.method_5667());
        killCounts.remove(player.method_5667());
    }

    @Override
    protected void onPlayerEliminated(class_3222 player) {
        // In KitPvP, players respawn instead of being eliminated
        alivePlayers.add(player.method_5667());
        spectators.remove(player);

        // Find killer and award kill
        var lastAttacker = player.method_49107();
        if (lastAttacker instanceof class_3222 killer) {
            int kills = killCounts.getOrDefault(killer.method_5667(), 0) + 1;
            killCounts.put(killer.method_5667(), kills);

            int streak = killStreaks.getOrDefault(killer.method_5667(), 0) + 1;
            killStreaks.put(killer.method_5667(), streak);

            var stats = EpicCraftMod.getInstance().getStatsManager();
            stats.addKill(killer, GameType.KITPVP);

            var economy = EpicCraftMod.getInstance().getEconomyManager();
            int reward = 5 + (streak * 2);
            economy.addCoins(killer, reward);
            TextUtil.sendMessage(killer, "\u00a7a+" + reward + " coins \u00a78(\u00a7c" + kills + " kills\u00a78)");

            if (streak >= 3) {
                broadcastMessage("\u00a76\u00a7l\uD83D\uDD25 " + killer.method_5477().getString() +
                    " \u00a7eis on a \u00a7c" + streak + " kill streak\u00a7e!");
            }

            // Heal killer partially
            killer.method_6033(Math.min(killer.method_6063(), killer.method_6032() + 4));
        }

        // Respawn with kit
        killStreaks.put(player.method_5667(), 0);

        // Respawn after small delay
        player.method_7336(class_1934.field_9215);
        spawnAtRandomLocation(player);
        player.method_6033(player.method_6063());
        player.method_7344().method_7580(20);
        applyKit(player, playerKits.getOrDefault(player.method_5667(), Kit.WARRIOR));

        TextUtil.sendMessage(player, "\u00a7eRespawned! Use \u00a7a/kit \u00a7eto change your kit.");
    }

    @Override
    protected void onGameStart(MinecraftServer server) {
        class_3218 world = server.method_30002();
        buildArena(world);

        for (class_3222 player : players) {
            Kit kit = playerKits.getOrDefault(player.method_5667(), Kit.WARRIOR);
            playerKits.put(player.method_5667(), kit);
            killStreaks.put(player.method_5667(), 0);
            killCounts.put(player.method_5667(), 0);

            applyKit(player, kit);
            spawnAtRandomLocation(player);
        }

        broadcastMessage("\u00a7e\u00a7lKitPvP \u00a7a- Fight and earn coins! /kit to change kit");
    }

    @Override
    protected void onGameEnd(class_3222 winner) {
        // Find top killer
        UUID topKiller = null;
        int topKills = 0;
        for (var entry : killCounts.entrySet()) {
            if (entry.getValue() > topKills) {
                topKills = entry.getValue();
                topKiller = entry.getKey();
            }
        }

        if (topKiller != null) {
            class_3222 topPlayer = EpicCraftMod.getServer().method_3760().method_14602(topKiller);
            if (topPlayer != null) {
                broadcastMessage("\u00a76\u00a7lMVP: \u00a7e" + topPlayer.method_5477().getString() +
                    " \u00a77with \u00a7c" + topKills + " kills!");
            }
        }
    }

    @Override
    protected void onTick(MinecraftServer server) {
        // KitPvP doesn't end by elimination - runs until timer or admin stop
        // Void check
        for (class_3222 player : new ArrayList<>(getAlivePlayers())) {
            if (player.method_23318() < 50) {
                // Just respawn them
                spawnAtRandomLocation(player);
                player.method_6033(player.method_6063());
            }
        }
    }

    @Override
    protected void checkWinCondition() {
        // KitPvP doesn't end by player count
    }

    @Override
    protected void onCleanup() {
        playerKits.clear();
        killStreaks.clear();
        killCounts.clear();
    }

    public void selectKit(class_3222 player, Kit kit) {
        playerKits.put(player.method_5667(), kit);
        if (state == GameState.IN_GAME) {
            applyKit(player, kit);
        }
        TextUtil.sendMessage(player, "\u00a7aKit selected: " + kit.color + kit.name);
    }

    private void showKitSelection(class_3222 player) {
        TextUtil.sendMessage(player, "\u00a76\u00a7l=== Select a Kit ===");
        for (Kit kit : Kit.values()) {
            TextUtil.sendMessage(player, kit.color + "\u00a7l" + kit.name +
                " \u00a78| \u00a77/kit " + kit.name().toLowerCase());
        }
    }

    private void applyKit(class_3222 player, Kit kit) {
        player.method_31548().method_5448();

        switch (kit) {
            case WARRIOR -> {
                player.method_31548().method_5447(0, new class_1799(class_1802.field_8371));
                player.method_31548().method_5447(1, new class_1799(class_1802.field_8463, 3));
                player.method_31548().field_7548.set(0, new class_1799(class_1802.field_8660));
                player.method_31548().field_7548.set(1, new class_1799(class_1802.field_8396));
                player.method_31548().field_7548.set(2, new class_1799(class_1802.field_8523));
                player.method_31548().field_7548.set(3, new class_1799(class_1802.field_8743));
            }
            case ARCHER -> {
                player.method_31548().method_5447(0, new class_1799(class_1802.field_8528));
                player.method_31548().method_5447(1, new class_1799(class_1802.field_8102));
                player.method_31548().method_5447(2, new class_1799(class_1802.field_8107, 32));
                player.method_31548().method_5447(3, new class_1799(class_1802.field_8463, 2));
                player.method_31548().field_7548.set(0, new class_1799(class_1802.field_8370));
                player.method_31548().field_7548.set(1, new class_1799(class_1802.field_8218));
                player.method_31548().field_7548.set(2, new class_1799(class_1802.field_8577));
                player.method_31548().field_7548.set(3, new class_1799(class_1802.field_8267));
            }
            case TANK -> {
                player.method_31548().method_5447(0, new class_1799(class_1802.field_8528));
                player.method_31548().method_5447(1, new class_1799(class_1802.field_8463, 5));
                player.method_31548().method_5447(2, new class_1799(class_1802.field_8255));
                player.method_31548().field_7548.set(0, new class_1799(class_1802.field_8285));
                player.method_31548().field_7548.set(1, new class_1799(class_1802.field_8348));
                player.method_31548().field_7548.set(2, new class_1799(class_1802.field_8058));
                player.method_31548().field_7548.set(3, new class_1799(class_1802.field_8805));
            }
            case ASSASSIN -> {
                player.method_31548().method_5447(0, new class_1799(class_1802.field_8802));
                player.method_31548().method_5447(1, new class_1799(class_1802.field_8634, 3));
                player.method_31548().method_5447(2, new class_1799(class_1802.field_8463, 1));
                player.method_31548().field_7548.set(0, new class_1799(class_1802.field_8313));
                player.method_31548().field_7548.set(1, new class_1799(class_1802.field_8218));
                player.method_31548().field_7548.set(2, new class_1799(class_1802.field_8873));
                player.method_31548().field_7548.set(3, new class_1799(class_1802.field_8283));
            }
        }
    }

    private void spawnAtRandomLocation(class_3222 player) {
        class_3218 world = player.method_5682().method_30002();
        int x = ARENA_CENTER.method_10263() + random.nextInt(ARENA_RADIUS * 2) - ARENA_RADIUS;
        int z = ARENA_CENTER.method_10260() + random.nextInt(ARENA_RADIUS * 2) - ARENA_RADIUS;
        LocationUtil.teleport(player, world, x + 0.5, ARENA_CENTER.method_10264() + 1, z + 0.5);
    }

    private void buildArena(class_3218 world) {
        int y = ARENA_CENTER.method_10264();
        int cx = ARENA_CENTER.method_10263();
        int cz = ARENA_CENTER.method_10260();

        // Build arena floor
        for (int x = -ARENA_RADIUS; x <= ARENA_RADIUS; x++) {
            for (int z = -ARENA_RADIUS; z <= ARENA_RADIUS; z++) {
                double dist = Math.sqrt(x * x + z * z);
                if (dist <= ARENA_RADIUS) {
                    class_2338 pos = new class_2338(cx + x, y, cz + z);
                    if (dist > ARENA_RADIUS - 2) {
                        world.method_8501(pos, class_2246.field_22108.method_9564());
                    } else if ((Math.abs(x) + Math.abs(z)) % 4 < 2) {
                        world.method_8501(pos, class_2246.field_28900.method_9564());
                    } else {
                        world.method_8501(pos, class_2246.field_28896.method_9564());
                    }

                    // Clear above
                    for (int dy = 1; dy <= 15; dy++) {
                        world.method_8501(pos.method_10086(dy), class_2246.field_10124.method_9564());
                    }
                }
            }
        }

        // Build some obstacles/structures
        buildPillar(world, new class_2338(cx + 10, y + 1, cz + 10));
        buildPillar(world, new class_2338(cx - 10, y + 1, cz - 10));
        buildPillar(world, new class_2338(cx + 10, y + 1, cz - 10));
        buildPillar(world, new class_2338(cx - 10, y + 1, cz + 10));

        buildWall(world, new class_2338(cx + 5, y + 1, cz), 5, Direction.Z);
        buildWall(world, new class_2338(cx - 5, y + 1, cz), 5, Direction.Z);
        buildWall(world, new class_2338(cx, y + 1, cz + 5), 5, Direction.X);
        buildWall(world, new class_2338(cx, y + 1, cz - 5), 5, Direction.X);

        // Arena walls
        for (int angle = 0; angle < 360; angle++) {
            double rad = Math.toRadians(angle);
            int x = cx + (int) (ARENA_RADIUS * Math.cos(rad));
            int z = cz + (int) (ARENA_RADIUS * Math.sin(rad));
            for (int dy = 1; dy <= 5; dy++) {
                world.method_8501(new class_2338(x, y + dy, z), class_2246.field_10499.method_9564());
            }
        }
    }

    private enum Direction { X, Z }

    private void buildPillar(class_3218 world, class_2338 pos) {
        for (int dy = 0; dy < 4; dy++) {
            world.method_8501(pos.method_10086(dy), class_2246.field_10056.method_9564());
        }
        world.method_8501(pos.method_10086(4), class_2246.field_10131.method_9564());
    }

    private void buildWall(class_3218 world, class_2338 start, int length, Direction dir) {
        for (int i = -length; i <= length; i++) {
            class_2338 pos = dir == Direction.X
                ? start.method_10069(i, 0, 0)
                : start.method_10069(0, 0, i);
            world.method_8501(pos, class_2246.field_10056.method_9564());
            world.method_8501(pos.method_10084(), class_2246.field_10056.method_9564());
        }
    }
}
