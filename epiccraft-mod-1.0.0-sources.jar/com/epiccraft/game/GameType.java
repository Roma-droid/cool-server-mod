package com.epiccraft.game;

import net.minecraft.class_124;

public enum GameType {
    SKYWARS("SkyWars", "skywars", class_124.field_1075, 2, 12, 60),
    BEDWARS("BedWars", "bedwars", class_124.field_1061, 4, 16, 90),
    KITPVP("KitPvP", "kitpvp", class_124.field_1054, 2, 20, 0);

    private final String displayName;
    private final String id;
    private final class_124 color;
    private final int minPlayers;
    private final int maxPlayers;
    private final int gameDurationSeconds;

    GameType(String displayName, String id, class_124 color, int minPlayers, int maxPlayers, int gameDurationSeconds) {
        this.displayName = displayName;
        this.id = id;
        this.color = color;
        this.minPlayers = minPlayers;
        this.maxPlayers = maxPlayers;
        this.gameDurationSeconds = gameDurationSeconds;
    }

    public String getDisplayName() { return displayName; }
    public String getId() { return id; }
    public class_124 getColor() { return color; }
    public int getMinPlayers() { return minPlayers; }
    public int getMaxPlayers() { return maxPlayers; }
    public int getGameDurationSeconds() { return gameDurationSeconds; }

    public String getColoredName() {
        return color.toString() + "\u00a7l" + displayName;
    }
}
