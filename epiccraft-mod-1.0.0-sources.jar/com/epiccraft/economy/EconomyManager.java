package com.epiccraft.economy;

import com.epiccraft.EpicCraftMod;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_3222;

public class EconomyManager {
    private static final Path DATA_FILE = Path.of("config/epiccraft/economy.json");
    private final Map<UUID, Integer> balances = new ConcurrentHashMap<>();
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    public EconomyManager() {
        loadAll();
    }

    public int getCoins(class_3222 player) {
        return balances.getOrDefault(player.method_5667(), 0);
    }

    public void setCoins(class_3222 player, int amount) {
        balances.put(player.method_5667(), Math.max(0, amount));
    }

    public void addCoins(class_3222 player, int amount) {
        setCoins(player, getCoins(player) + amount);
    }

    public boolean removeCoins(class_3222 player, int amount) {
        int balance = getCoins(player);
        if (balance < amount) return false;
        setCoins(player, balance - amount);
        return true;
    }

    public void loadPlayer(class_3222 player) {
        // Data already in memory from loadAll
        if (!balances.containsKey(player.method_5667())) {
            balances.put(player.method_5667(), 100); // Starting balance
        }
    }

    public void savePlayer(class_3222 player) {
        saveAll();
    }

    public void loadAll() {
        try {
            if (Files.exists(DATA_FILE)) {
                String json = Files.readString(DATA_FILE);
                Type type = new TypeToken<Map<String, Integer>>() {}.getType();
                Map<String, Integer> data = gson.fromJson(json, type);
                if (data != null) {
                    data.forEach((k, v) -> balances.put(UUID.fromString(k), v));
                }
                EpicCraftMod.LOGGER.info("Loaded {} economy records", balances.size());
            }
        } catch (Exception e) {
            EpicCraftMod.LOGGER.error("Failed to load economy data", e);
        }
    }

    public void saveAll() {
        try {
            Files.createDirectories(DATA_FILE.getParent());
            Map<String, Integer> data = new HashMap<>();
            balances.forEach((k, v) -> data.put(k.toString(), v));
            Files.writeString(DATA_FILE, gson.toJson(data));
        } catch (Exception e) {
            EpicCraftMod.LOGGER.error("Failed to save economy data", e);
        }
    }
}
